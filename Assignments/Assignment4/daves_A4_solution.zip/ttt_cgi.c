#include <stdio.h>	//printf
#include <string.h>	//strlen
#include <sys/socket.h>	//socket
#include <arpa/inet.h>	//inet_addr
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

int main(int argc , char *argv[])
{
	printf("%s%c%c\n", "Content-Type:text/html;charset=iso-8859-1",13,10);
	printf("<html>\n<body>\n<table>\n<tr>\n<td>");

	char *address;
	char *port;
	char *command;
	char *username;
	char *password;
	char *gamename;
	char *square;

	char* data = getenv("QUERY_STRING");

	//printf( "data holds %s.<br \\>\r\n", data );

	address = strstr( data, "address=" ) + strlen("address=");

	port = strstr(data, "&port=" );
	*(port) = '\0';
	port+= strlen( "&port=" );

	data = port;
	
	username = strstr( data, "&username=" );
	*(username) = '\0';
	username+= strlen("&username=");

	data = username;

	password   = strstr( data, "&password=" );
	*(password) = '\0';
	password   += strlen("&password=");

	data = password;

	gamename = strstr( data, "&gamename=" );
	*(gamename) = '\0';
	gamename+= strlen("&gamename=");

	data = gamename;

	square   = strstr( data, "&square=" );
	*(square) = '\0';
	square   += strlen( "&square=");

	data = square;

	command = strstr(data, "&" );
	*command = '\0';
	command++;

	char *a = strstr(command, "=");
	*a = '\0';

	printf( "<form action=\"./ttt.cgi\">\r\n" );
        printf( "<b>Server Address: <input type=\"text\" name=\"address\" value=\"%s\" size=\"20\"><br />\r\n", address );
        printf( "<b>Server Port: <input type=\"text\" name=\"port\" value=\"%s\" size=\"20\"><br />\r\n", port );
        printf( "<b>Username: <input type=\"text\" name=\"username\" value=\"%s\" size=\"20\"><br />\r\n", username );
        printf( "<b>Password: <input type=\"text\" name=\"password\" value=\"%s\" size=\"20\"><br />\r\n", password );
        printf( "<b>Game Name: <input type=\"text\" name=\"gamename\" value=\"%s\" size=\"20\"><br />\r\n", gamename );
        printf( "<b>Square: <input type=\"text\" name=\"square\" value=\"%s\" size=\"20\"><br />\r\n", square );
        printf( "<input type=\"submit\" value=\"LOGIN\" name=\"LOGIN\">\r\n" );
        printf( "<input type=\"submit\" value=\"CREATE\" name=\"CREATE\">\r\n" );
        printf( "<input type=\"submit\" value=\"JOIN\" name=\"JOIN\">\r\n" );
        printf( "<input type=\"submit\" value=\"MOVE\" name=\"MOVE\">\r\n" );
        printf( "<input type=\"submit\" value=\"LIST\" name=\"LIST\">\r\n" );
        printf( "<input type=\"submit\" value=\"SHOW\" name=\"SHOW\">\r\n" );
	printf( "</form><br>\r\n" );
/*

	printf( "Address: %s<br \\>\r\n", address );
	printf( "Port: --%s--<br \\>\r\n", port );
	printf( "Username: --%s--<br \\>\r\n", username );
	printf( "Password: --%s--<br \\>\r\n", password );
	printf( "Command: --%s--<br \\>\r\n", command );
	printf( "Gamename: --%s--<br \\>\r\n", gamename );
	printf( "Square: --%s--<br \\>\r\n", square );	
*/
	int sock;
	struct sockaddr_in server;
	char server_reply[200];
	unsigned short int iport = atoi(port);
	
	server.sin_addr.s_addr = inet_addr( address );
	server.sin_family = AF_INET;
	server.sin_port = htons( iport );

	//Create socket
	sock = socket(AF_INET , SOCK_STREAM , 0);
	if (sock == -1)
	{
		printf("Could not create socket");
		return 0;
	}
	
	//Connect to remote server
        if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
        {
     	 printf("connect failed. Error");
	    return 0;
	}
	
	char message[2000];
	sprintf( message, "%s,%s,%s,%s,%s", command,username,password,gamename,square );
	//printf( "Sending the message %s to server.<br \\>\r\n", message );
	//Send some data
	if( send(sock , message , 200, 0) < 0)
	{
		puts("Send failed");
		return 0;
	}
	
	size_t read_size;
	int bytes_read = 0;
	char incoming_msg[2000];
	char temp[200];
	while( bytes_read < 2000 ){
		read_size = recv(sock , temp, 2000, 0);
		if(read_size <= 0){
		    puts("Server disconnected");
		    fflush(stdout);
		    close(sock);
		    return 0;
		}
		memcpy( incoming_msg+bytes_read, temp, read_size );
		bytes_read += read_size;
	}

	char* response = incoming_msg;
	while( *response ){

		if( *response == '\n' ){
			printf( "<br>");
		}
		else if( *response == ' ' ){
			printf( "&ensp;" );
		}
		else if( *response == '-' ){
			printf ( "&ndash;" );
		}
		else
		{
			printf( "%c", *response );
		}
		response++;
	}

	close(sock);

	return 0;
}
