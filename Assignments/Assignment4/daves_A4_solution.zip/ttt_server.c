#include <stdio.h>
#include <string.h>	
#include <sys/socket.h>
#include <arpa/inet.h>	
#include <unistd.h>	
#include <stdlib.h>
#include <time.h>

struct USER{
	char username[100];
	char password[100];
	struct USER *next;
};

enum GAME_STATE{ 
	CREATOR_WON=-2,
	IN_PROGRESS_CREATOR_NEXT=-1,
	DRAW=0,
	IN_PROGRESS_CHALLENGER_NEXT=1,
	CHALLENGER_WON=2
};

struct GAME{
	char gamename[100];
	struct USER *creator;
	struct USER *challenger;
	enum GAME_STATE state;
	char ttt[3][3];
	struct GAME *next;
};

struct USER *user_list_head = NULL;
struct GAME *game_list_head = NULL;

int main(int argc , char *argv[])
{
	int socket_desc , client_sock , c , read_size;
	struct sockaddr_in server , client;
	char client_message[2000];

	unsigned short int port = 8888;

	if( argc > 1 )
		port = (unsigned short int)atoi(argv[1]);
	
	//Create socket
	socket_desc = socket(AF_INET , SOCK_STREAM , 0);
	if (socket_desc == -1)
	{
		printf("Could not create socket");
	}
	
	//Prepare the sockaddr_in structure
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons( port );
	
	if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
	{
		perror("bind failed. Error");
		return 1;
	}

	listen(socket_desc , 3);

	printf( "Game server ready on port %d.\n", port );

	while( 1 ){
		c = sizeof(struct sockaddr_in);

		//accept connection from an incoming client
		client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
		if (client_sock < 0)
		{
			perror("accept failed");
			return 1;
		}

		char temp[200];
		memset(client_message, '\0', 200);
		int bytes_read = 0;
		while( bytes_read < 200 ){
			read_size = recv(client_sock , temp , 200, 0);
			if(read_size <= 0){
				puts("Client disconnected");
				fflush(stdout);
				close(client_sock);
				close(socket_desc);
				return 0;
			}
			memcpy( client_message+bytes_read, temp, read_size );
			bytes_read += read_size;
		}

	  	char response[2000];
	  	response[0] = '\0';
	  	char* command = strtok( client_message, "," );
	  	char *username = strtok( NULL, "," );
	  	char *password = strtok( NULL, ",");

		if( command == NULL || username == NULL || password == NULL ){
			sprintf( response, "MUST ENTER A VALID COMMAND WITH ARGUMENTS FROM THE LIST:\n" );
			sprintf( response+strlen(response), "LOGIN,USER,PASS\n" );
			sprintf( response+strlen(response), "CREATE,USER,PASS,GAMENAME\n" );
			sprintf( response+strlen(response), "JOIN,USER,PASS,GAMENAME,SQUARE\n" );
			sprintf( response+strlen(response), "MOVE,USER,PASS,GAMENAME,SQUARE\n" );
			sprintf( response+strlen(response), "LIST,USER,PASS\n" );
			sprintf( response+strlen(response), "SHOW,USER,PASS,GAMENAME\n" );
			write(client_sock , response , 2000);  
		  	close(client_sock);
			continue;
		}

		int user_found = 0;
		int user_error = 0;
	  	struct USER *user_ptr = user_list_head;
		struct USER *prev_user = NULL;
		while( user_ptr ){
			if( strcmp( user_ptr->username, username ) == 0 ){
				user_found = 1;
				if( strcmp( user_ptr->password, password ) != 0 ){	
					strcpy( response, "BAD PASSWORD" ); 
					write(client_sock , response , 2000);  
		  			close(client_sock);
		  			user_error = 1;
				}
				break;
			}
			prev_user = user_ptr;
			user_ptr = user_ptr->next;
		}

		if( user_error == 1 ){
			continue;
		}

		if( user_found == 0 && strcmp( command, "LOGIN" ) != 0 ){
			strcpy( response, "USER NOT FOUND" ); 
			write(client_sock , response , 2000);  
			close(client_sock);
			continue;
		}

		if( strcmp( command, "LOGIN" ) == 0 ){
			if( user_found == 0 ){
				strcpy( response, "NEW USER CREATED OK" ); 
				struct USER *new = (struct USER*)malloc(sizeof(struct USER));
				strcpy(new->username, username);
				strcpy(new->password, password);
				new->next = NULL;
				if( prev_user ){
					prev_user->next = new;
				}
				else{
					user_list_head = new;
				}
			}	
			else{
				strcpy( response, "EXISTING USER LOGIN OK" );
			}
	  	}
	  	else if( strcmp( command, "CREATE" ) == 0 ){ 
	  		char *game_name = strtok( NULL, ",");

			if( game_name == NULL ){
				sprintf( response, "CREATE COMMAND MUST BE CALLED AS FOLLOWS:\n" );
				sprintf( response+strlen(response), "CREATE,USER,PASS,GAMENAME\n" );
				write(client_sock , response , 2000);  
		  		close(client_sock);
		  		continue;
			}

	  		struct GAME *game = game_list_head;
			struct GAME *prev = NULL;
			
			while(game){
				if( strcmp( game->gamename, game_name ) == 0){
					sprintf( response, "GAME NAME %s ALREADY EXISTED", game_name ); 
					break;
				}
				prev = game;
				game = game->next;
			}
			
			if( response[0] == '\0' ){
				struct GAME *new_game = (struct GAME*)malloc(sizeof(struct GAME));
				new_game->creator = user_ptr;
				strcpy(new_game->gamename, game_name);
				new_game->challenger = NULL;
				new_game->state = IN_PROGRESS_CHALLENGER_NEXT; 
				for( int row=0; row<3; row++ )
					for( int col=0; col<3; col++ )
						new_game->ttt[row][col] = ' ';
				new_game->next = NULL;
				if( prev )
					prev->next = new_game;
				else
					game_list_head = new_game;

				struct GAME *game = new_game;

				sprintf( response, "%sGAME %s CREATED. WAITING FOR OPPONENT TO JOIN.\r\n",response, game->gamename);
				sprintf( response, "%sa  %c | %c | %c \r\n",response,  game->ttt[0][0],  game->ttt[0][1],  game->ttt[0][2]);
				sprintf( response, "%s  ---|---|---\r\n", response );
				sprintf( response, "%sb  %c | %c | %c \r\n", response, game->ttt[1][0],  game->ttt[1][1],  game->ttt[1][2]);
				sprintf( response, "%s  ---|---|---\r\n", response );
				sprintf( response, "%sc  %c | %c | %c \r\n", response, game->ttt[2][0],  game->ttt[2][1],  game->ttt[2][2]);
				sprintf( response, "%s\r\n", response );
				sprintf( response, "%s   %c   %c   %c\r\n", response, '1', '2', '3' );
			}
		}
		else if( strcmp( command, "JOIN" ) == 0 ){ 
			char *game_name = strtok( NULL, ",");
			char *first_move = strtok( NULL, ",");
			if( game_name == NULL || first_move == NULL ){
				sprintf( response, "JOIN COMMAND MUST BE CALLED AS FOLLOWS:\n" );
				sprintf( response+strlen(response), "JOIN,USER,PASS,GAMENAME,SQUARE\n" );
				write(client_sock , response , 2000);  
		  		close(client_sock);
		  		continue;
			}
			
			if( first_move[0] < 'a' || first_move[0] > 'c' ){
				strcpy( response, "INVALID MOVE. ROW MUST BE a-c" );
			}
			if( first_move[1] < '1' || first_move[1] > '3' ){
				strcpy( response, "INVALID MOVE. COL MUST BE 1-3" );
			}

			struct GAME *game = game_list_head;

			int row = first_move[0] - 'a';
			int col = first_move[1] - '1';

			if( response[0] == '\0' ){

				int game_found = 0;
				int game_error = 0;
				while(game){
					if( strcmp( game->gamename, game_name ) == 0){
						game_found = 1;
						if( game->challenger != NULL ){
							sprintf( response, "GAME %s ALREADY HAS A CHALLENGER", game_name );
							game_error = 1;
						}
						break;
					}
					game = game->next;
				}


				if( game_found == 0 ){
					sprintf( response, "GAME %s DOES NOT EXIST", game_name );
				}
				else if( game_error == 0 ){
					//printf( "Found game %p.\n", game );
					//printf( "Playing move %s on row=%d, col=%d.\n", first_move, row, col );
					char move_type[100];
					sprintf( move_type, "IN PROGRESS: %s TO MOVE NEXT AS o", game->creator->username );
					game->challenger = user_ptr;
					game->ttt[row][col] = 'x';
					game->state = IN_PROGRESS_CREATOR_NEXT;
					sprintf( response, "GAME %s BETWEEN %s AND %s.\n", game->gamename, game->creator->username, game->challenger->username );
					sprintf( response, "%s%s\r\n",response, move_type );
					sprintf( response, "%sa  %c | %c | %c \r\n",response,  game->ttt[0][0],  game->ttt[0][1],  game->ttt[0][2]);
					sprintf( response, "%s  ---|---|---\r\n", response );
					sprintf( response, "%sb  %c | %c | %c \r\n", response, game->ttt[1][0],  game->ttt[1][1],  game->ttt[1][2]);
					sprintf( response, "%s  ---|---|---\r\n", response );
					sprintf( response, "%sc  %c | %c | %c \r\n", response, game->ttt[2][0],  game->ttt[2][1],  game->ttt[2][2]);
					sprintf( response, "%s\r\n", response );
					sprintf( response, "%s   %c   %c   %c\r\n", response, '1', '2', '3' );
				}
			}
		}
		else if( strcmp( command, "MOVE" ) == 0 ){ 
			char *game_name = strtok( NULL, ",");
			char *move = strtok( NULL, ",");
			if( game_name == NULL || move == NULL ){
				sprintf( response, "MOVE COMMAND MUST BE CALLED AS FOLLOWS:\n" );
				sprintf( response+strlen(response), "MOVE,USER,PASS,GAMENAME,SQUARE\n" );
				write(client_sock , response , 2000);  
		  		close(client_sock);
		  		continue;
			}

			if( move[0] < 'a' || move[0] > 'c' ){
				sprintf( response, "INVALID MOVE %s. ROW MUST BE a-c", move );
			}
			if( move[1] < '1' || move[1] > '3' ){
				sprintf( response, "INVALID MOVE %s. COL MUST BE 1-3", move );
			}

			struct GAME *game = game_list_head;

			int row = move[0] - 'a';
			int col = move[1] - '1';

			if( response[0] == '\0' ){

				int game_found = 0;
				int game_error = 0;

				while(game){
					if( strcmp( game->gamename, game_name ) == 0){
						game_found = 1;
						printf( "Matched game name=%s, state=%d.\n", game->gamename, game->state );
						if( game->state == DRAW || game->state == CREATOR_WON || game->state == CHALLENGER_WON ){
							sprintf( response, "CANNOT MAKE A MOVE IN COMPLETED GAME %s", game->gamename );
							game_error = 1;
						}
						else if( game->ttt[row][col] != ' ' ){
							sprintf( response, "INVALID MOVE, SQUARE NOT EMPTY" );
							game_error = 1;
						}
						else if( game->state == IN_PROGRESS_CHALLENGER_NEXT ){
							if( game->challenger != user_ptr ){
								sprintf( response, "INVALID USER. ONLY %s CAN MAKE THE NEXT MOVE AS x IN GAME %s", game->challenger->username, game->gamename );
								game_error = 1;
								break;
							}
							game->ttt[row][col] = 'x';
							game->state = IN_PROGRESS_CREATOR_NEXT; 
							if( ( game->ttt[0][col] == 'x' && game->ttt[1][col] == 'x' && game->ttt[2][col] == 'x'         ) ||
							    ( game->ttt[row][0] == 'x' && game->ttt[row][1] == 'x' && game->ttt[row][2] == 'x'         ) ||
							    ( row==col && game->ttt[0][0] == 'x' && game->ttt[1][1] == 'x' && game->ttt[2][2] == 'x'   ) ||
							    ( row==2-col && game->ttt[2][0] == 'x' && game->ttt[1][1] == 'x' && game->ttt[0][2] == 'x' ) ){

								game->state = CHALLENGER_WON;	
							}
						}
						else if( game->state == IN_PROGRESS_CREATOR_NEXT ){
							if( game->creator != user_ptr ){
								sprintf( response, "INVALID USER. ONLY %s CAN MAKE THE NEXT MOVE AS o IN GAME %s", game->creator->username, game->gamename );
								game_error = 1;
								break;
							}
							game->ttt[row][col] = 'o';
							game->state = IN_PROGRESS_CHALLENGER_NEXT; 
							if( ( game->ttt[0][col] == 'o' && game->ttt[1][col] == 'o' && game->ttt[2][col]  == 'o' ) ||
							    ( game->ttt[row][0] == 'o' && game->ttt[row][1] == 'o' && game->ttt[row][2] == 'o'  ) ||
							    ( row==col && game->ttt[0][0] == 'o' && game->ttt[1][1] == 'o' && game->ttt[2][2] == 'o' ) ||
							    ( row==2-col && game->ttt[2][0] == 'o' && game->ttt[1][1] == 'o' && game->ttt[0][2] == 'o' ) ){

								game->state = CREATOR_WON;	
							}
						}
						break;
					}
					game = game->next;
				}

				if( game_found == 0 ){
					sprintf( response, "GAME %s DOES NOT EXIST", game_name );
				}

				if( game_found == 0 || game_error == 1 ){
					write(client_sock , response , 2000);  
					close(client_sock);
					continue;
				}
				if( game_found && game->state != CREATOR_WON && game->state != CHALLENGER_WON
				    && game->ttt[0][0] != ' ' && game->ttt[0][1] != ' ' && game->ttt[0][2] != ' ' 
				    && game->ttt[1][0] != ' ' && game->ttt[1][1] != ' ' && game->ttt[1][2] != ' ' 
				    && game->ttt[2][0] != ' ' && game->ttt[2][1] != ' ' && game->ttt[2][2] != ' ' ){
					game->state = DRAW;
				}

				char move_type[100];

				if( game->state == DRAW ){
					strcpy( move_type, "GAME OVER: DRAW" );
				}
				else if( game->state == CREATOR_WON ){
					sprintf( move_type, "GAME OVER: %s WON", game->creator->username );
				}
				else if( game->state == CHALLENGER_WON ){
					sprintf( move_type, "GAME OVER: %s WON", game->challenger->username );
				}
				else if( game->state == IN_PROGRESS_CREATOR_NEXT ){
					sprintf( move_type, "IN PROGRESS: %s TO MOVE NEXT AS o", game->creator->username );
				}
				else if( game->state == IN_PROGRESS_CHALLENGER_NEXT ){
					sprintf( move_type, "IN PROGRESS: %s TO MOVE NEXT AS x", game->challenger->username );
				}
	
				sprintf( response, "GAME %s BETWEEN %s AND %s.\n", game->gamename, game->creator->username, game->challenger->username );
				sprintf( response, "%s%s\r\n",response, move_type );
				sprintf( response, "%sa  %c | %c | %c \r\n",response,  game->ttt[0][0],  game->ttt[0][1],  game->ttt[0][2]);
				sprintf( response, "%s  ---|---|---\r\n", response );
				sprintf( response, "%sb  %c | %c | %c \r\n", response, game->ttt[1][0],  game->ttt[1][1],  game->ttt[1][2]);
				sprintf( response, "%s  ---|---|---\r\n", response );
				sprintf( response, "%sc  %c | %c | %c \r\n", response, game->ttt[2][0],  game->ttt[2][1],  game->ttt[2][2]);
				sprintf( response, "%s\r\n", response );
				sprintf( response, "%s   %c   %c   %c\r\n", response, '1', '2', '3' );
			}
		}
		else if( strcmp( command, "LIST" ) == 0 ){ 

			strcpy( response, "LIST OF GAMES:\n");
			struct GAME* game = game_list_head;

			while( game ){
				char move_type[100];
				if( game->state == DRAW ){
					strcpy( move_type, "GAME OVER: DRAW" );
				}
				else if( game->state == CREATOR_WON ){
					sprintf( move_type, "GAME OVER: %s WON", game->creator->username );
				}
				else if( game->state == CHALLENGER_WON ){
					sprintf( move_type, "GAME OVER: %s WON", game->challenger->username );
				}
				else if( game->state == IN_PROGRESS_CREATOR_NEXT ){
					sprintf( move_type, "IN PROGRESS: %s TO MOVE NEXT AS o", game->creator->username );
				}
				else if( game->state == IN_PROGRESS_CHALLENGER_NEXT ){
					sprintf( move_type, "IN PROGRESS: %s TO MOVE NEXT AS x", game->challenger->username );
				}
				sprintf( response+strlen(response), "GAME %s: CREATED BY %s, CHALLENGED BY: %s. %s\n", game->gamename, game->creator->username, game->challenger->username, move_type );
				game = game->next;
			}
		}
		else if( strcmp( command, "SHOW" ) == 0 ){

			char *game_name = strtok( NULL, ",");
			if( game_name == NULL  ){
				sprintf( response, "SHOW COMMAND MUST BE CALLED AS FOLLOWS:\n" );
				sprintf( response+strlen(response), "MOVE,USER,PASS,GAMENAME\n" );
				write(client_sock , response , 2000);  
		  		close(client_sock);
		  		continue;
			}

			struct GAME *game = game_list_head;
			int game_found = 0;
			while(game){
				if( strcmp( game->gamename, game_name ) == 0){
					game_found = 1;
					break;
				}
				game = game->next;
			}

			if( game_found == 0 ){
				sprintf( response, "GAME %s DOES NOT EXIST", game_name );
			}
			else{
				char move_type[100];

				if( game->state == DRAW ){
					strcpy( move_type, "GAME OVER: DRAW" );
				}
				else if( game->state == CREATOR_WON ){
					sprintf( move_type, "GAME OVER: %s WON", game->creator->username );
				}
				else if( game->state == CHALLENGER_WON ){
					sprintf( move_type, "GAME OVER: %s WON", game->challenger->username );
				}
				else if( game->state == IN_PROGRESS_CREATOR_NEXT ){
					sprintf( move_type, "IN PROGRESS: %s TO MOVE NEXT AS o", game->creator->username );
				}
				else if( game->state == IN_PROGRESS_CHALLENGER_NEXT ){
					sprintf( move_type, "IN PROGRESS: %s TO MOVE NEXT AS x", game->challenger->username );
				}
	
				sprintf( response, "GAME %s BETWEEN %s AND %s.\n", game->gamename, game->creator->username, game->challenger->username );
				sprintf( response, "%s%s\r\n",response, move_type );
				sprintf( response, "%sa  %c | %c | %c \r\n",response,  game->ttt[0][0],  game->ttt[0][1],  game->ttt[0][2]);
				sprintf( response, "%s  ---|---|---\r\n", response );
				sprintf( response, "%sb  %c | %c | %c \r\n", response, game->ttt[1][0],  game->ttt[1][1],  game->ttt[1][2]);
				sprintf( response, "%s  ---|---|---\r\n", response );
				sprintf( response, "%sc  %c | %c | %c \r\n", response, game->ttt[2][0],  game->ttt[2][1],  game->ttt[2][2]);
				sprintf( response, "%s\r\n", response );
				sprintf( response, "%s   %c   %c   %c\r\n", response, '1', '2', '3' );
			}
		}
		else{
	  		sprintf( response, "COMMAND %s NOT IMPLEMENTED", command );
		}

		write(client_sock , response , 2000);  
		close(client_sock);
	}

	close(socket_desc);	
	
	return 0;
}
