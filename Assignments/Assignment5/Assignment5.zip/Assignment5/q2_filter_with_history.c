/* FILE: q2_filter_with_history.c
*
* This file is a starter that we have begun for you to complete question 2.
* You are allowed to re-do it in any way that you choose, but in order for it
* to be completed in a sensible amount of time, I think you should heavily consider
* using both this code and the helper functions in A5_provided_functions.h
*
* Recommended to start: read through all this code carefully and all the provided
* functions. Write down a plan, then start coding and run make q2_test frequently.
*
* Date: Nov 27, 2018.
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "A5_provided_functions.h"

// This is our suggested data structure that you might use to keep track of the history
struct IMAGE_HISTORY{
	int history_length;   // This can hold how many operations have been done, including 1 load and N filters
	int active_image;     // This can represent where we are between 0 and length-1 based on undo/redo
	int each_image_size;  // In order to restore, we need to hold the images in memory/file. How big is each?
	unsigned char** history_array;  // This can be an array of raw image buffers. See the helper functions provided
	                                // to help you work with these.

} filter_history; // Remember writing this name here means we have one instance of the struct, global variable.


int readHistory( char *hist_filename ){

	printf( "readHistory unimplemented. Complete me.\n" );
	return 0;
}

int writeHistory( char *hist_filename ){

	printf( "writeHistory unimplemented. Complete me.\n" );
	return 0;	
}

int main( int argc, char* argv[] ){

	if( argc < 2 ){
		printf( "img_filter must be called with at least one command. From the following list:\n");
		printf( "$ %s load input_filename\n", argv[0] );
		printf( "$ %s filter width [filter_weights](size widthxwidth)\n", argv[0] );
		printf( "$ %s undo\n", argv[0] );
		printf( "$ %s redo\n", argv[0] );
		exit(EXIT_FAILURE);
	}

	char *command = argv[1];

	// TODO load hist_list

	if( strcmp( command, "load") == 0 ){

		if( argc < 3 ){
			printf( "img_filter load command requires an image filename to be specified.\n");
			exit(EXIT_FAILURE);
		}

		char *load_filename = argv[2];

		unsigned char*   header_data;
		unsigned int     header_size, width, height, num_colors;
		unsigned char*** pixel_array = NULL;

		pixel_array = bmp_to_3D_array( load_filename,       &header_data, 
	                             &header_size,  &width, 
	                             &height,       &num_colors   );
	                             
		if( pixel_array == NULL ){
			printf( "Error: bmp_to_3D_array failed for file %s.\n", load_filename );
			return 0;
		}

		// Now the image will live in output.bmp - it will be the active image.
		bmp_from_3D_array( "output.bmp", header_data, header_size, pixel_array,
	                 	   width,   height,      num_colors );

		// Now what? Think about how to put the image into the history, so that it can be
		// accessed for the next filtering operations. Complete the rest of this command.
		
	}
	else if( strcmp( command, "filter" ) == 0 ){

		if( argc < 4 ){
			printf( "img_filter filter command requires a filter width and a square filter of size (widthxwidth).\n");
			exit(EXIT_FAILURE);
		}

		int filter_width = atoi( argv[2] );

		// Complete this, read the rest of the filter into some variable, use it to filter the 
		// active image, and update history as required.

		
	}
	else if( strcmp( command, "undo" ) == 0 ){

		// Complete this

	}
	else if( strcmp( command, "redo" ) == 0 ){

		// Complete this
	}
	else{
		printf( "Command %s is not valid. Please type one of: load, filer, undo, redo.\n", command );
		return -1;
	}

	// It makes sense to always write the history after the operations have completed. Make sure you put
	// readHistory calls where they're required.
	writeHistory( "history.dat" );

	return 0;
				
}

